#!/bin/bash

java -jar controleRempes.jar
